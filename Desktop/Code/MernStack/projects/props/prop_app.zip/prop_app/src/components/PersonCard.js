import React, { Component } from 'react';
import ReactDom from 'react-dom';

class PersonCard extends Component {
    render() {
        return (
            <div>
                <h1> { this.props.lastName }, { this.props.firstName } </h1>
                <p> Age: {this.props.age } </p>
                <p> Hair Color: {this.props.hairColor } </p>
            </div>
        )
    }
}
// const jane = <PersonCard lastName="Doe" firstName="Jane" age="45" hairColor="Black"/>;
// ReactDom.render(jane, document.getElementById('root'));

// const john = <PersonCard lastName="Smith" firstName="John" age="88" hairColor="Brown"/>;
// ReactDom.render(john, document.getElementById('root'));

// const info = [
//     {lastName: "Doe", firstName: "Jane", age: 45, hairColor: "Black"},
// ]

export default PersonCard;