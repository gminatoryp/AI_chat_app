import React, { useEffect, useState } from 'react'
import axios from 'axios';
import { Link, navigate } from '@reach/router';
export default props => {
    const { initialName, initialSrc, initialPosition, initialChest, initialPhrase, initialPegleg, initialEyepatch, initialHookhand, onSubmitProp } = props;
    const [name, setName] = useState(initialName);
    const [src, setSrc] = useState(initialSrc);
    const [position, setPosition] = useState(initialPosition);
    const [chest, setChest] = useState(initialChest);
    const [phrase, setPhrase] = useState(initialPhrase);
    const [pegleg, setPegleg] = useState(true);
    const [eyepatch, setEyepatch] = useState(true);
    const [hookhand, setHookhand] = useState(true);
    const [errors, setErrors] = useState(null);
    const onSubmitHandler = e => {
        e.preventDefault();
        createPirate({name, src, position, chest, phrase, pegLeg:pegleg, eyePatch:eyepatch, hookHand:hookhand});
    }

    const createPirate = pirate => {
        console.log(pirate)
        axios.post('http://localhost:8000/api/pirates', pirate)
            .then(res=>{
                navigate('/pirates')
                console.log(res.data)
            })
            .catch((err) => {
                setErrors(err.response.data.errors);
                console.log(err.response.data.errors);

        });
    };
    
    const pegleghandler = (e) => {
        setPegleg(!pegleg)
    }

    return (
        <form onSubmit={onSubmitHandler}>
            <Link to={"/pirates/"}>
                Home
            </Link> 
            <div>
            <p>

                <label>Name</label><br />
                {errors?.name && (
                    <span style={{ color: "red"}} >{errors?.name?.message}</span>
                )}
                <input 
                    type="text" 
                    name="name" 
                    value={name} 
                    onChange={(e) => { setName(e.target.value) }} />
            </p>
            <p>
                <label>Image URL</label><br />
                {errors?.name && (
                    <span style={{ color: "red"}} >{errors?.src?.message}</span>
                )}
                <input 
                    type="text" 
                    name="src" 
                    value={src} 
                    onChange={(e) => { setSrc(e.target.value) }} />
            </p>
            <p>
                <label> Crew Position</label><br />
                {errors?.name && (
                    <span style={{ color: "red"}} >{errors?.position?.message}</span>
                )}
                <select
                onChange={(event) => {
                    setPosition(event.target.value);
                }}
                type="text"
                >
                    <option value="Captain">Captain</option>
                    <option value="First Mate">First Mate</option>
                    <option value="Quarter Master">Quarter Master</option>
                    <option value="Boatswain">Boatswain</option>
                    <option value="Power Monkey">Powder Monkey</option>

                </select>
            </p>
            <p>
                <label> # of Treasure Chests</label><br />
                {errors?.name && (
                    <span style={{ color: "red"}} >{errors?.chest?.message}</span>
                )}
                <select
                onChange={(event) => {
                    setChest(event.target.value);
                }}
                type="text"
                >
                    <option value="one">1</option>
                    <option value="two">2</option>
                    <option value="three">3</option>

                </select>
            </p>
            <p>
                <label>Catch Phrase</label><br />
                {errors?.name && (
                    <span style={{ color: "red"}} >{errors?.phrase?.message}</span>
                )}
                <input 
                    type="text" 
                    name="phrase" 
                    value={phrase} 
                    onChange={(e) => { setPhrase(e.target.value) }} />
            </p>
            </div>
        <div>
            <label>Peg Leg</label>
            <input
            onChange={(event) => {
                pegleghandler(event.target.checked)
            }}
            type="checkbox" checked={pegleg}
            />
        </div>

        <div>
            <label>Eye Patch</label>
            <input
            onChange={(event) => {
                setEyepatch(event.target.checked);
            }}

            type="checkbox" checked={eyepatch} 
            
            />
        </div>

        <div>
            <label>Hook Hand</label>
            <input
            onChange={(event) => {
                setHookhand(event.target.unchecked);
            }}
            type="checkbox" checked={hookhand}
            />
        </div>

            <input type="submit" />
            {JSON.stringify(pegleg)}
        </form>
        
    )
}

