
import React from 'react';
import { Redirect, Router} from '@reach/router';
import Main from './views/Main';
import PirateDetail from './views/PirateDetail';
import PirateUpdate from './views/PirateUpdate';
import CreatePirate from './components/CreatePirate';

function App() {
  return (
    <div classname="container" style={{ width:"50%", margin: "0 auto"   }}>
      <nav class="navbar sticky-top navbar-light bg-light">
        <a class="navbar-brand" href="#">Pirate Crew</a>
      </nav>

      <Router>    
        <Redirect from="/" to="/pirates" noThrow="true"/>
        <Main path='/pirates/'/>
        <CreatePirate path='/pirates/new/'/>
        <PirateDetail path='/pirates/:id'/>
        <PirateUpdate path='/pirates/:id/edit'/>
        
      </Router>
  

    </div>
  );
}
export default App;