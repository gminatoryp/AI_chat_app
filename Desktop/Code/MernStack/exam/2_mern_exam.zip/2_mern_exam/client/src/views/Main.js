import React, { useEffect, useState } from 'react'
import axios from 'axios';
import { Link } from '@reach/router';
import CreatePirate from '../components/CreatePirate';
import PirateList from '../components/PirateList';
export default () => {
    const [pirates, setPirates] = useState([]);
    const [loaded, setLoaded] = useState(false);
    useEffect(() => {
        axios.get('http://localhost:8000/api/pirates')
            .then(res =>{ 
                setPirates(res.data)
                setLoaded(true);
            });
    }, [])
    const removeFromDom = pirateID => {
        setPirates(pirates.filter(pirate => pirate._id != pirateID));
    }
    const createPirate = pirate => {
        axios.post('http://localhost:8000/api/pirates', pirate)
            .then(res=>{
                setPirates([...pirates, res.data]);
                console.log(res.data)
                console.log(pirate)
            })
            .catch((err) => {
                console.log(err.response);
            });
    }
    return (
        <div>
            <Link to='/pirates/new/' >Add a Pirate</Link>
           {/* <petForm onSubmitProp={createpirate} initialFirstName="" initialLastName="" initialBreed=""/> */}
           <hr/>
           {loaded && <PirateList pirates={pirates} removeFromDom={removeFromDom}/>}
        </div>
    )
}

