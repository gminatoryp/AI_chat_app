import React, { useEffect, useState } from 'react'
import axios from 'axios';
import { navigate, Link } from '@reach/router';
import UpdatePirate from '../components/UpdatePirate';
export default props => {
    const { id } = props;
    const [pet, setPirate] = useState();
    const [loaded, setLoaded] = useState(false);
    const [errors, setErrors] = useState(null);

    useEffect(() => {
        axios.get('http://localhost:8000/api/pirates/' + id)
            .then(res => {
                setPirate(res.data);
                setLoaded(true);
            })
    }, [])

    const updatePirate = newPet => {
        console.log(newPet)
        console.log("checking update")
        axios.put(`http://localhost:8000/api/pirates/${id}/edit`, newPet)
            .then(res => console.log(res))
            .catch((err) => {
                setErrors(err.response.data.errors);
                console.log(err.response.data.errors);

    })};
    console.log(pet)
    return (
        <div>
            <h1>Deep Sea Davy</h1>
            {loaded && (
                <>  
                    <UpdatePirate
                        onSubmitProp={updatePirate}
                        initialName={pet.name}
                        initialPosition={pet.position}
                        initialTreasure={pet.treasure}
                        errors={errors}
                    />
                
                </>
            )}
        </div>
    )
}

