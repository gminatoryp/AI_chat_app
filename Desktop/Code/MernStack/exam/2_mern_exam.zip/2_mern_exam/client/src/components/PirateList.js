import React, { useEffect, useState } from 'react'
import { Link } from '@reach/router';
import axios from 'axios';
import DeleteButton from './DeleteButton';
export default props => {
    const [pirates, setPirates] = useState([]);
    const [loaded, setLoaded] = useState(false);
    useEffect(() => {
        axios.get('http://localhost:8000/api/pirates')
        .then(res => {
            console.log("**************")
            console.log(res.data)
            setPirates(res.data);
            setLoaded(true)
        })
        .catch((err) => {
            console.log(err);
        });
    }, [])

    const removeFromDom = pirateID => {
        setPirates(pirates.filter(pirate => pirate._id !== pirateID))
    }
    return (
        <div>
            
            {loaded && (

            pirates.map((pirate, idx) => {
                return <div key={idx}>
                    <table>
                        <tr>
                            <th>{pirate.name}</th>

                        </tr>
                        <tr>
                            <td>

                            <img
                            width="50%"
                            src={pirate.src}
                            alt={pirate.location}
                            />
                            </td>
                            <td>
                            <Link to={"/pirates/" + pirate._id}>View Pirate
                            </Link>
                            </td>
                            <td>
                            <DeleteButton pirateId={pirate._id} successCallback={()=>removeFromDom(pirate._id)}/>
                            </td>
                        </tr>
                    </table>
                    </div>
                
                
            })
            )
        }
           
        </div>
    )
}



