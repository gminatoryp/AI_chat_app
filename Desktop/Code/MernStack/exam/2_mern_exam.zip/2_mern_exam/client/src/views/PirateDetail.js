import React, { useEffect, useState } from 'react'
import axios from 'axios';
import { Link } from "@reach/router";
export default (props) => {
    const [pirate, setPirate] = useState({})
    useEffect(() => {
    axios.get("http://localhost:8000/api/pirates/" + props.id)
        .then(res => {
            console.log(res)
            setPirate(res.data)})
        .catch(err => {
            console.log(err)
        })
    }, [])

    return (
        <div>
            <Link to={"/pirates/"}>
                Home
            </Link> 
            <p>Pirate Name: {pirate.name}</p>
            Image URL:
            <img
            width="50%"
            src={pirate.src}
            alt="whatever"
            />
                
            
            <p>Crew Position: {pirate.position}</p>
            <p>Treasures: {pirate.chest}</p>
            <p>Catch Phrase: {pirate.phrase} </p>
            <p>Peg Leg: {pirate.pegLeg == true ?
                <p> Yes </p> :
                <p> No </p>
            }
            </p>
            <p>Eye Patch: {pirate.eyePatch == true ?
                <p> Yes </p> :
                <p> No </p>
            }</p>
            <p>Hook Hand: Eye Patch: {pirate.hookHand == true ?
                <p> Yes </p> :
                <p> No </p>
            }</p>
            {JSON.stringify(pirate)}
        </div>
    )
}