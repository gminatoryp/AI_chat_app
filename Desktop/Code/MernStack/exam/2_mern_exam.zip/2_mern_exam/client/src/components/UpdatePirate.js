import React, { useEffect, useState } from 'react'
import axios from 'axios';
import { Link, navigate } from '@reach/router';
export default props => {
    const { initialName, initialBreed, initialColor, onSubmitProp, errors } = props;
    const [name, setName] = useState(initialName);
    const [breed, setBreed] = useState(initialBreed);
    const [color, setColor] = useState(initialColor);
    const onSubmitHandler = e => {
        e.preventDefault();
        onSubmitProp({name, breed, color});
        console.log(errors)
        console.log("these are errors")
        if(name=="" || breed==="" || color===""){
            console.log("name is empty")
        } else {
            navigate("/pets")
        }
        
        
        // const newPet = {
        //     name: name,
        //     breed: breed,
        //     color: color,
        // };
    }
        
    return (

        <form onSubmit={onSubmitHandler }>
      
            <Link to={"/pets/"}>
                Home
            </Link>
            <p>

                <label>Name</label><br />
                {errors?.name && (
                    <span sytle={{ color: "red"}} >{errors?.name?.message}</span>
                )}
                <input 
                    type="text" 
                    name="name" 
                    value={name} 
                    onChange={(e) => { setName(e.target.value) }} />
            </p>
            <p>
                <label>Breed</label><br />
                {errors?.name && (
                    <span sytle={{ color: "red"}} >{errors?.breed?.message}</span>
                )}
                <input 
                    type="text" 
                    name="breed" 
                    value={breed} 
                    onChange={(e) => { setBreed(e.target.value) }} />
            </p>
            <p>
                <label> Color</label><br />
                {errors?.name && (
                    <span sytle={{ color: "red"}} >{errors?.color?.message}</span>
                )}
                <input 
                    type="text" 
                    name="color" 
                    value={color} 
                    onChange={(e) => { setColor(e.target.value) }} />
            </p>
            <input type="submit" />
        </form>

    )
}

